@echo off
echo ========================================================
echo  Metroid Dread Recomp - Anbernic RG556 Wireless Sideload
echo ========================================================
echo.
set /p IP="Enter your Anbernic RG556 IP address (e.g. 192.168.1.150): "
echo Connecting to %IP%:5555...
adb connect %IP%:5555
echo Installing MetroidDread-RG556.apk...
adb install -r MetroidDread-RG556.apk
echo Creating data directories on RG556 internal storage...
adb shell mkdir -p /storage/emulated/0/SwitchRecomp/MetroidDread_data/romfs
adb shell mkdir -p /storage/emulated/0/SwitchRecomp/MetroidDread_data/exefs
echo.
echo ========================================================
echo Sideload Complete! 
echo Place your dumped Metroid Dread v2.1.0 'romfs' files into:
echo /storage/emulated/0/SwitchRecomp/MetroidDread_data/romfs
echo ========================================================
pause
