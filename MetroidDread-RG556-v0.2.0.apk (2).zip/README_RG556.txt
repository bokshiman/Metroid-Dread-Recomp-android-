METROID DREAD RECOMP - ANBERNIC RG556 ANDROID PACKAGE
=======================================================

DEVICE PROFILE:
- Device: Anbernic RG556 Handheld Gaming Console
- Processor: Unisoc Tiger T820 (8-core, 6nm)
- GPU: Mali-G57 MC4 @ 850MHz (OpenGL ES 3.2 / Vulkan)
- Display: 5.48-inch AMOLED (1920x1080 Native)
- OS: Android 13

HOW TO PLAY ON YOUR ANBERNIC RG556:
1. Sideload the APK onto your RG556 (via USB cable, MicroSD card, or Wireless ADB).
2. Allow "All Files Access" when prompted on first launch.
3. Copy your legally dumped Metroid Dread v2.1.0 update files to:
   /storage/emulated/0/SwitchRecomp/MetroidDread_data/romfs/
4. Launch Metroid Dread from your RG556 app launcher or Daijisho / Beacon / Pegasus frontend.
5. RG556 built-in gamepad controls (A, B, X, Y, D-pad, Hall Sticks, Analog Triggers) are auto-mapped!
